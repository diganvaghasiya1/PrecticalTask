package com.example.practicaltask.model

class ImageList : ArrayList<ImageListItem>()