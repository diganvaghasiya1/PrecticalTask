package com.example.practicaltask.model

public class ImageListItem(
   public val author: String,
   public val download_url: String,
   public val height: Int,
   public  val id: String,
   public val url: String,
   public val width: Int
)